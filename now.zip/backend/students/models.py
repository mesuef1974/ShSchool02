from django.db import models

class Guardian(models.Model):
    id = models.UUIDField(primary_key=True, default=models.UUIDField, editable=False)
    full_name_ar = models.CharField(max_length=128)
    phone = models.CharField(max_length=32)

class School(models.Model):
    id = models.UUIDField(primary_key=True, default=models.UUIDField, editable=False)
    name_ar = models.CharField(max_length=256)
    moe_code = models.CharField(max_length=32, unique=True)
    level = models.CharField(max_length=32)

class AcademicYear(models.Model):
    id = models.UUIDField(primary_key=True, default=models.UUIDField, editable=False)
    code = models.CharField(max_length=9, unique=True)

class Term(models.Model):
    id = models.UUIDField(primary_key=True, default=models.UUIDField, editable=False)
    year = models.ForeignKey(AcademicYear, on_delete=models.CASCADE)
    code = models.CharField(max_length=8)
    class Meta:
        unique_together = ('year', 'code')

class Student(models.Model):
    id = models.UUIDField(primary_key=True, default=models.UUIDField, editable=False)
    guardian = models.ForeignKey(Guardian, on_delete=models.CASCADE)
    full_name_ar = models.CharField(max_length=128)
    national_id = models.CharField(max_length=32, unique=True)
    dob = models.DateField()
    nationality = models.CharField(max_length=64)

class Enrollment(models.Model):
    id = models.UUIDField(primary_key=True, default=models.UUIDField, editable=False)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    year = models.ForeignKey(AcademicYear, on_delete=models.CASCADE)
    grade = models.CharField(max_length=16)
    section = models.CharField(max_length=8)
    class Meta:
        unique_together = ('student', 'school', 'year', 'grade', 'section')


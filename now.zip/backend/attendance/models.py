from django.db import models

class AttendanceRecord(models.Model):
    id = models.UUIDField(primary_key=True, default=models.UUIDField, editable=False)
    enrollment = models.ForeignKey('students.Enrollment', on_delete=models.CASCADE)
    date = models.DateField()
    period = models.SmallIntegerField()
    status = models.CharField(max_length=16)
    class Meta:
        unique_together = ('enrollment', 'date', 'period')
        indexes = [
            models.Index(fields=['date']),
        ]


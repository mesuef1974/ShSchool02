from django.db import models

class Subject(models.Model):
    id = models.UUIDField(primary_key=True, default=models.UUIDField, editable=False)
    title_ar = models.CharField(max_length=128)

class ClassRoom(models.Model):
    id = models.UUIDField(primary_key=True, default=models.UUIDField, editable=False)
    school = models.ForeignKey('students.School', on_delete=models.CASCADE)
    year = models.ForeignKey('students.AcademicYear', on_delete=models.CASCADE)
    grade = models.CharField(max_length=16)
    section = models.CharField(max_length=8)
    capacity = models.SmallIntegerField(null=True)
    class Meta:
        unique_together = ('school', 'year', 'grade', 'section')

class TeachingAssignment(models.Model):
    id = models.UUIDField(primary_key=True, default=models.UUIDField, editable=False)
    teacher = models.UUIDField()
    class_room = models.ForeignKey(ClassRoom, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    weekly_load = models.SmallIntegerField()
    class Meta:
        unique_together = ('teacher', 'class_room', 'subject')

